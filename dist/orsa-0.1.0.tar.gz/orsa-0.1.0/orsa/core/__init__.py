"""
Core module for saga
"""
